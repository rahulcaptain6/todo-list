const quizData = [
    {
        question: "What is Python?",
        options: ["A snake species", "A programming language", "A framework for web development", "A data visualization tool"],
        correctAnswer: "A programming language"
    },
    {
        question: "Explain the purpose of PEP 8.",
        options: ["A type of snake", "A programming style guide for Python", "A module for data analysis", "A Python enhancement proposal"],
        correctAnswer: "A programming style guide for Python"
    },
    // Add more Python interview questions and options as needed
    // ...
    {
        question: "How does Python support multiple inheritance?",
        options: ["Using interfaces", "Using mixins", "Using decorators", "Using metaclasses"],
        correctAnswer: "Using mixins"
    },
    // Additional 50 questions
    {
        question: "What is the purpose of the `__init__` method in a class?",
        options: ["Initialization method", "Destructor method", "Class method", "Static method"],
        correctAnswer: "Initialization method"
    },
    {
        question: "How does Python handle memory management?",
        options: ["Manual memory management", "Automatic memory management", "Garbage collection", "Memory pools"],
        correctAnswer: "Automatic memory management"
    },
    // Add more questions...
    {
        question: "What is a closure in Python?",
        options: ["A function with no arguments", "A function that returns another function", "A function with only one argument", "A built-in Python function"],
        correctAnswer: "A function that returns another function"
    },
    {
        question: "How can you achieve parallelism in Python?",
        options: ["Threading", "Multiprocessing", "Asynchronous programming", "All of the above"],
        correctAnswer: "All of the above"
    },
    // Add more questions...
];

const quizContainer = document.getElementById("quiz");
const submitButton = document.getElementById("submit");

function buildQuiz() {
    quizData.forEach((question, index) => {
        const questionDiv = document.createElement("div");
        questionDiv.classList.add("question");
        questionDiv.innerHTML = `<h3>${index + 1}. ${question.question}</h3>`;

        question.options.forEach(option => {
            const label = document.createElement("label");
            label.innerHTML = `<input type="radio" name="question${index}" value="${option}"> ${option}`;
            questionDiv.appendChild(label);
        });

        quizContainer.appendChild(questionDiv);
    });
}

function showResults() {
    const answerContainers = quizContainer.querySelectorAll('.question');

    let score = 0;

    quizData.forEach((question, index) => {
        const answerContainer = answerContainers[index];
        const selectedOption = answerContainer.querySelector(`input[name="question${index}"]:checked`);

        if (selectedOption) {
            const userAnswer = selectedOption.value;
            if (userAnswer === question.correctAnswer) {
                score++;
            }
        }
    });

    alert(`You scored ${score} out of ${quizData.length}`);
}

buildQuiz();

submitButton.addEventListener("click", showResults);
