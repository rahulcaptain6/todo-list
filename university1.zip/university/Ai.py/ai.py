import random

class AIInterview:
    def __init__(self):
        self.questions = {
            "Tell me about yourself.": "I am an AI created to assist in interviews.",
            "What are your strengths?": "I am good at processing and analyzing information.",
            "Can you handle stress?": "I don't experience stress, so I can handle any situation calmly.",
            # Add more questions and responses as needed
        }

    def ask_question(self):
        return random.choice(list(self.questions.keys()))

    def get_answer(self, question):
        return self.questions.get(question, "I don't have a specific answer for that question.")

    def conduct_interview(self, num_questions=5):
        print("Welcome to the AI Interview!")
        print("Let's get started...\n")

        for _ in range(num_questions):
            question = self.ask_question()
            user_answer = input(f"Q: {question}\nYour Answer: ")

            ai_answer = self.get_answer(question)
            print(f"\nAI: {ai_answer}\n")

        print("Interview completed. Thank you!")

if __name__ == "__main__":
    interview_system = AIInterview()
    interview_system.conduct_interview()
