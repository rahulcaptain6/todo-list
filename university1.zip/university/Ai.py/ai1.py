import tkinter as tk
from tkinter import simpledialog, messagebox
import random

class AIInterview:
    def __init__(self, master):
        self.master = master
        self.master.title("AI Interview")
        
        self.questions = {
            "Tell me about yourself.": "I am an AI created to assist in interviews.",
            "What are your strengths?": "I am good at processing and analyzing information.",
            "Can you handle stress?": "I don't experience stress, so I can handle any situation calmly.",
            # Add more questions and responses as needed
        }

        self.label = tk.Label(master, text="Welcome to the AI Interview!")
        self.label.pack()

        self.ask_question_button = tk.Button(master, text="Ask Question", command=self.ask_question)
        self.ask_question_button.pack()

        self.questions_asked = 0
        self.max_questions = 10

    def ask_question(self):
        if self.questions_asked < self.max_questions:
            question = random.choice(list(self.questions.keys()))
            user_answer = simpledialog.askstring("User Input", f"Q: {question}\nYour Answer:")
            
            ai_answer = self.get_answer(question)
            messagebox.showinfo("AI Answer", f"AI: {ai_answer}")

            self.questions_asked += 1
        else:
            messagebox.showinfo("Interview Completed", "You have completed 10 questions. Thank you!")

    def get_answer(self, question):
        return self.questions.get(question, "I don't have a specific answer for that question.")

if __name__ == "__main__":
    root = tk.Tk()
    interview_system = AIInterview(root)
    root.mainloop()
