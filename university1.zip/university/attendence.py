import tkinter as tk
from tkinter import messagebox
from tkinter import font
from datetime import datetime
import subprocess

class AttendanceApp:
    def __init__(self, master):
        self.master = master
        self.master.title("University Attendance App")

        # Initialize variables
        self.students = []
        self.attendance_dict = {}
        self.attendance_completed = False  # Flag to track if attendance for all students is completed

        # Create GUI components
        heading_font = font.Font(family='Helvetica', size=16, weight='bold')
        entry_font = font.Font(family='Helvetica', size=12)  # Change the font size here

        self.label = tk.Label(master, text="University Attendance", font=heading_font)
        self.label.pack(pady=10)

        self.label_instructions_name = tk.Label(master, text="Enter Student Name:")
        self.label_instructions_name.pack()

        self.entry_name = tk.Entry(master, font=entry_font)
        self.entry_name.pack()

        self.label_instructions_id = tk.Label(master, text="Enter Student ID:")
        self.label_instructions_id.pack()

        self.entry_id = tk.Entry(master, font=entry_font)
        self.entry_id.pack()

        self.mark_attendance_button = tk.Button(master, text="Mark Attendance", command=self.mark_attendance)
        self.mark_attendance_button.pack(pady=10)

        self.view_attendance_button = tk.Button(master, text="View Attendance", command=self.view_attendance)
        self.view_attendance_button.pack(pady=10)

    def mark_attendance(self):
        student_name = self.entry_name.get()
        student_id = self.entry_id.get()

        if not student_name or not student_id:
            messagebox.showerror("Error", "Please enter both student name and ID.")
            return

        student_key = f"{student_name} ({student_id})"

        if student_key not in self.students:
            self.students.append(student_key)

        if student_key not in self.attendance_dict:
            self.attendance_dict[student_key] = 1
            messagebox.showinfo("Attendance Marked", f"Attendance marked for {student_key}")

            # Check if attendance for all students is completed
            if len(self.attendance_dict) == len(self.students):
                self.attendance_completed = True
                messagebox.showinfo("Attendance Completed", "Attendance for all students is marked.")

        else:
            messagebox.showwarning("Duplicate Entry", f"Attendance already marked for {student_key}")

    def view_attendance(self):
        if not self.attendance_completed:
            messagebox.showwarning("Incomplete Attendance", "Attendance for all students is not yet completed.")
            return

        attendance_summary = "Attendance Summary:\n"

        for student in self.students:
            attendance_status = "Present" if self.attendance_dict.get(student) else "Absent"
            attendance_summary += f"{student}: {attendance_status}\n"

        messagebox.showinfo("Attendance Summary", attendance_summary)

        # Save attendance to file when viewing
        self.save_attendance_to_file()

    def save_attendance_to_file(self):
        if not self.attendance_completed:
            messagebox.showwarning("Incomplete Attendance", "Attendance for all students is not yet completed. Cannot save data.")
            return

        today_date = datetime.now().strftime("%Y-%m-%d")
        file_name = f"attendance_data_{today_date}.txt"

        with open(file_name, "a") as file:
            file.write(f"\nAttendance for {today_date}:\n")
            for student, attendance_status in self.attendance_dict.items():
                file.write(f"{student}: {attendance_status}\n")

        # Open Notepad with the file
        subprocess.run(["notepad", file_name])

if __name__ == "__main__":
    root = tk.Tk()
    app = AttendanceApp(root)
    root.geometry("300x500")  # Set a specific size for the window
    root.mainloop()
