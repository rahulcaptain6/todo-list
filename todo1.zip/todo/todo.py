from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from tkinter import simpledialog

class Todo:
    def __init__(self, root):
        self.root = root
        self.root.title('To-Do List')
        self.root.geometry('400x300+300+150')

        self.tasks = []

        style = ttk.Style()
        style.configure('TButton', font=('Arial', 12))
        style.configure('TLabel', font=('Arial', 20, 'bold'))

        self.label = ttk.Label(self.root, text='To-Do List', style='TLabel')
        self.label.pack(pady=10)

        self.task_entry = ttk.Entry(self.root, font=('Arial', 12))
        self.task_entry.pack(pady=10)

        add_button = ttk.Button(self.root, text='Add Task', command=self.add_task)
        add_button.pack()

        view_button = ttk.Button(self.root, text='View Tasks', command=self.view_tasks)
        view_button.pack()

        update_button = ttk.Button(self.root, text='Update Task', command=self.update_task)
        update_button.pack()

        complete_button = ttk.Button(self.root, text='Mark as Complete', command=self.mark_as_complete)
        complete_button.pack()

    def add_task(self):
        task = self.task_entry.get().strip()
        if task:
            self.tasks.append(task)
            messagebox.showinfo('Success', 'Task added successfully!')
            self.task_entry.delete(0, END)
        else:
            messagebox.showwarning('Error', 'Please enter a task.')

    def view_tasks(self):
        if not self.tasks:
            messagebox.showinfo('Info', 'No tasks to display.')
        else:
            task_list = '\n'.join(self.tasks)
            messagebox.showinfo('Tasks', task_list)

    def update_task(self):
        selected_task = self.task_entry.get().strip()
        if selected_task in self.tasks:
            updated_task = simpledialog.askstring('Update Task', f'Update task: "{selected_task}" to:')
            if updated_task:
                index = self.tasks.index(selected_task)
                self.tasks[index] = updated_task
                messagebox.showinfo('Success', 'Task updated successfully!')
                self.task_entry.delete(0, END)
            else:
                messagebox.showwarning('Error', 'Please enter a valid task for updating.')
        else:
            messagebox.showwarning('Error', 'Task not found in the list.')

    def mark_as_complete(self):
        selected_task = self.task_entry.get().strip()
        if selected_task in self.tasks:
            self.tasks.remove(selected_task)
            completed_task = selected_task + ' - Complete'
            self.tasks.append(completed_task)
            messagebox.showinfo('Success', 'Task marked as complete!')
            self.task_entry.delete(0, END)
        else:
            messagebox.showwarning('Error', 'Task not found in the list.')

def main():
    root = Tk()
    ui = Todo(root)
    root.mainloop()

if __name__ == "__main__":
    main()
