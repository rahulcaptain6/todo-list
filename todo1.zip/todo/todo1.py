from tkinter import *
from tkinter import ttk
from tkinter.font import Font

class Todo:
    def __init__(self, root):
        self.root = root
        self.root.title('To-do-list ')
        self.root.geometry('650x410+300+150')

        self.label = Label(self.root, text='To-do-list-App',
                        font='ariel, 25 bold', width=20, bd=5, bg='orange', fg='black')
        self.label.grid(row=0, column=0, columnspan=3)

        self.label2 = Label(self.root, text='Add Task',
                            font='ariel, 18 bold', width=10, bd=5, bg='orange', fg='black')
        self.label2.grid(row=1, column=0, padx=10, pady=10)

        self.label3 = Label(self.root, text='Task',
                            font='ariel, 18 bold', width=10, bd=5, bg='orange', fg='black')
        self.label3.grid(row=1, column=2, padx=10, pady=10)

        self.tasks = []
        self.main_text = Listbox(self.root, height=9, bd=5, width=23, font="ariel, 20 italic bold")
        self.main_text.grid(row=2, column=2, rowspan=4, padx=10, pady=10)

        self.txt_font = Font(family='ariel', size=10, weight='bold')
        self.txt = Text(self.root, bd=5, height=2, width=30, font=self.txt_font)
        self.txt.grid(row=2, column=0, padx=10, pady=10, rowspan=2)

        add_btn = Button(self.root, text='Add Task', command=self.add_task)
        add_btn.grid(row=3, column=0, padx=10, pady=10, rowspan=2)  # Move the "Add Task" button below the entry and text widget

        update_btn = Button(self.root, text='Update Task', command=self.update_task)
        update_btn.grid(row=4, column=0, padx=10, pady=10)

        #view_btn = Button(self.root, text='View Tasks', command=self.view_tasks)
        #view_btn.grid(row=4, column=2, padx=10, pady=10)

        clear_btn = Button(self.root, text='Clear Tasks', command=self.clear_tasks)
        clear_btn.grid(row=3, column=1, padx=10, pady=10)

        complete_btn = Button(self.root, text='Mark as Complete', command=self.mark_as_complete)
        complete_btn.grid(row=4, column=1, padx=10, pady=10)

        task_btn = Button(self.root, text='Task', command=self.open_task_window)
        task_btn.grid(row=5, column=2, padx=10, pady=10)

    def add_task(self):
        task_description = self.txt.get("1.0", END).strip()
        if task_description:
            self.tasks.append(task_description)
            self.main_text.insert(END, task_description)
            self.txt.delete("1.0", END)

    def update_task(self):
        selected_task_index = self.main_text.curselection()
        if selected_task_index:
            new_description = self.txt.get("1.0", END).strip()
            self.tasks[selected_task_index[0]] = new_description
            self.main_text.delete(selected_task_index)
            self.main_text.insert(selected_task_index, new_description)
            self.txt.delete("1.0", END)

    def view_tasks(self):
        self.main_text.delete(0, END)
        for task in self.tasks:
            self.main_text.insert(END, task)
            self.main_text.insert(END, "\n")

    def clear_tasks(self):
        self.tasks = []
        self.main_text.delete(0, END)

    def mark_as_complete(self):
        selected_task_index = self.main_text.curselection()
        if selected_task_index:
            task = self.tasks[selected_task_index[0]]
            task = task + " - Complete"
            self.tasks[selected_task_index[0]] = task
            self.main_text.delete(selected_task_index)
            self.main_text.insert(selected_task_index, task)

    def open_task_window(self):
        task_window = Toplevel(self.root)
        task_window.title("Task Window")
        task_window.geometry("300x200")

        task_label = Label(task_window, text="This is a Task Window", font="ariel, 15")
        task_label.pack(pady=20)

def main():
    root = Tk()
    ui = Todo(root)
    root.mainloop()

if __name__ == "__main__":
    main()
