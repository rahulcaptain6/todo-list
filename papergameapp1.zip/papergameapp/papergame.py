import tkinter as tk
import random

class RockPaperScissorsGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Rock-Paper-Scissors Game")
        self.root.geometry("300x500")  # Set window size to 300x500
        self.root.configure(bd=5, relief=tk.SOLID, bg='black')  # Add dark border

        self.user_score = 0
        self.computer_score = 0

        self.heading_label = tk.Label(root, text="Rock-Paper-Scissors Game", font=("Helvetica", 16, "bold"), bg="#4CAF50", fg="white")
        self.heading_label.pack(pady=10)

        self.label = tk.Label(root, text="Choose Rock, Paper, or Scissors:")
        self.label.pack(pady=10)

        self.buttons_frame = tk.Frame(root)
        self.buttons_frame.pack()

        self.create_button("Rock", width=10, height=2)
        self.create_button("Paper", width=10, height=2)
        self.create_button("Scissors", width=10, height=2)

        # Increase font size of the output label and add a border
        self.output_label = tk.Label(root, text="", padx=10, pady=5, font=("Helvetica", 12), bd=2, relief=tk.SOLID)
        self.output_label.pack(pady=10)

        self.score_label = tk.Label(root, text="Score - You: 0, Computer: 0")
        self.score_label.pack(pady=5)

    def create_button(self, choice, width, height):
        button = tk.Button(self.buttons_frame, text=choice, command=lambda: self.play(choice), width=width, height=height, bg="#e0e0e0")
        button.pack(side=tk.LEFT, padx=5)

    def play(self, user_choice):
        computer_choice = random.choice(["Rock", "Paper", "Scissors"])
        result = self.determine_winner(user_choice, computer_choice)

        # Update the output label with yellow color for win and red color for loss
        if "win" in result:
            self.output_label.config(text=f"Your choice: {user_choice}\nComputer's choice: {computer_choice}\n{result}", fg="green")
            self.user_score += 1
        elif "lose" in result:
            self.output_label.config(text=f"Your choice: {user_choice}\nComputer's choice: {computer_choice}\n{result}", fg="red")
            self.computer_score += 1
        else:
            self.output_label.config(text=f"Your choice: {user_choice}\nComputer's choice: {computer_choice}\n{result}", fg="blue")

        self.score_label.config(text=f"Score - You: {self.user_score}, Computer: {self.computer_score}")

    def determine_winner(self, user_choice, computer_choice):
        if user_choice == computer_choice:
            return "It's a tie!"
        elif (user_choice == "Rock" and computer_choice == "Scissors") or \
             (user_choice == "Scissors" and computer_choice == "Paper") or \
             (user_choice == "Paper" and computer_choice == "Rock"):
            return "You win!"
        else:
            return "You lose!"

if __name__ == "__main__":
    root = tk.Tk()
    app = RockPaperScissorsGame(root)
    root.mainloop()
